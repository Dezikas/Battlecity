using System;
using System.Drawing;
using System.Reflection.Metadata;
using System.Windows.Forms;
using static battlecity.Form1;

namespace battlecity
{
    public partial class Form1 : Form
    {
        private const int GridSize = 20;
        private const int TileSize = 40;

        private int[,] map = new int[GridSize, GridSize]
        {
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 0, 0, 2, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 1, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
        };

        Image originalTankImage = Image.FromFile(@"C:\Users\miste\Downloads\battlecity\battlecity\TANKUTISS.png");
        private PictureBox playerTank;
        private System.Windows.Forms.Timer gameLoop = new System.Windows.Forms.Timer();
        private System.ComponentModel.IContainer components = null;
        private float tankSpeed = 4.0f;
        private float tankRotationAngle = 0.0f;
        private bool isMovingUp = false;
        private bool isMovingDown = false;
        private bool isMovingLeft = false;
        private bool isMovingRight = false;
        private List<EnemyTank> enemyTanks = new List<EnemyTank>();
        private Random random = new Random();
        private bool IsGameOver = false;



        public Form1()
        {
            InitializeGame();
            InitializeEnemyTanks();
        }


        private void InitializeGame()
        {

            this.Text = "Battle City Game";
            this.Size = new Size(850, 880);
            this.DoubleBuffered = true;

            gameLoop.Interval = 1000 / 60;
            gameLoop.Tick += GameLoop_Tick;
            gameLoop.Start();

            enemyTankBulletTimer.Interval = 2000;
            enemyTankBulletTimer.Tick += EnemyTankBulletTimer_Tick;
            enemyTankBulletTimer.Start();

            playerTank = new PictureBox
            {
                Image = originalTankImage,
                Size = originalTankImage.Size,
                Location = new Point(380, 360),
                Tag = "PlayerTank"
            };
            this.Controls.Add(playerTank);

            this.KeyDown += Form1_KeyDown;
            this.KeyUp += Form1_KeyUp;

            shootingCooldownTimer.Interval = shootingCooldown;
            shootingCooldownTimer.Tick += ShootingCooldownTimer_Tick;
            shootingCooldownTimer.Start();
        }

        

        private void GameLoop_Tick(object sender, EventArgs e)
        {
            float newRotationAngle = tankRotationAngle;

            if (isMovingUp)
            {
                MoveTank(0, -tankSpeed);
                newRotationAngle = 0.0f;
            }
            else if (isMovingDown)
            {
                MoveTank(0, tankSpeed);
                newRotationAngle = 180.0f;
            }
            else if (isMovingLeft)
            {
                MoveTank(-tankSpeed, 0);
                newRotationAngle = -90.0f;
            }
            else if (isMovingRight)
            {
                MoveTank(tankSpeed, 0);
                newRotationAngle = 90.0f;
            }

            if (newRotationAngle != tankRotationAngle)
            {
                playerTank.Image = RotateImage((Bitmap)originalTankImage, newRotationAngle);
                tankRotationAngle = newRotationAngle;
            }

            if (isShooting)
            {
                CreateBullet();
            }

            UpdateBullets();

            UpdateEnemyTanks();

            UpdateBullets();
            UpdateEnemyTanks();
            UpdateEnemyBullets();

            if (enemyTanks.Count == 0)
            {
                IsGameOver = true;
            }

            if (IsGameOver)
            {
                gameLoop.Stop();
                MessageBox.Show("Gave over!");
                Close();
            }


            Invalidate();
        }


        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.W:
                    isMovingUp = true;
                    isMovingDown = false;
                    isMovingLeft = false;
                    isMovingRight = false;
                    break;
                case Keys.S:
                    isMovingDown = true;
                    isMovingUp = false;
                    isMovingLeft = false;
                    isMovingRight = false;
                    break;
                case Keys.A:
                    isMovingLeft = true;
                    isMovingUp = false;
                    isMovingDown = false;
                    isMovingRight = false;
                    break;
                case Keys.D:
                    isMovingRight = true;
                    isMovingUp = false;
                    isMovingDown = false;
                    isMovingLeft = false;
                    break;
                case Keys.Space:
                    isShooting = true;
                    break;
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.W:
                    isMovingUp = false;
                    break;
                case Keys.S:
                    isMovingDown = false;
                    break;
                case Keys.A:
                    isMovingLeft = false;
                    break;
                case Keys.D:
                    isMovingRight = false;
                    break;
                case Keys.Space:
                    isShooting = false;
                    break;
            }
        }

        private void MoveTank(float deltaX, float deltaY)
        {
            float newX = playerTank.Left + deltaX;
            float newY = playerTank.Top + deltaY;

            if (newX >= 0 && newX + playerTank.Width <= ClientSize.Width &&
                newY >= 0 && newY + playerTank.Height <= ClientSize.Height &&
                !IsCollidingWithObstacle(newX, newY))
            {
                playerTank.Left = (int)newX;
                playerTank.Top = (int)newY;
            }
        }

        private bool IsCollidingWithObstacle(float x, float y)
        {
            // calculate all the four corners of the grid
            int tankGridLeft = (int)(x / TileSize);
            int tankGridRight = (int)((x + playerTank.Width) / TileSize);
            int tankGridTop = (int)(y / TileSize);
            int tankGridBottom = (int)((y + playerTank.Height) / TileSize);

            // check colissions of all four corners
            if (map[tankGridLeft, tankGridTop] == 1 ||
                map[tankGridRight, tankGridTop] == 1 ||
                map[tankGridLeft, tankGridBottom] == 1 ||
                map[tankGridRight, tankGridBottom] == 1||
                map[tankGridLeft, tankGridTop] == 2 ||
                map[tankGridRight, tankGridTop] == 2 ||
                map[tankGridLeft, tankGridBottom] == 2 ||
                map[tankGridRight, tankGridBottom] == 2)
                
            {
                return true;
            }

            return false;
        }

        private Bitmap RotateImage(Bitmap image, float angle)
        {
            Bitmap rotatedImage = new Bitmap(image.Width, image.Height);
            using (Graphics g = Graphics.FromImage(rotatedImage))
            {
                g.TranslateTransform(image.Width / 2, image.Height / 2);
                g.RotateTransform(angle);
                g.TranslateTransform(-image.Width / 2, -image.Height / 2);
                g.DrawImage(image, new Point(0, 0));
            }
            return rotatedImage;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Image wallImage = Image.FromFile(@"C:\Users\miste\Downloads\battlecity\battlecity\siena.png");
            Image rockImage = Image.FromFile(@"C:\Users\miste\Downloads\battlecity\battlecity\akmuo.png");
            for (int i = 0; i < GridSize; i++)
            {
                for (int j = 0; j < GridSize; j++)
                {
                    int cellValue = map[i, j];
                    int x = i * TileSize;
                    int y = j * TileSize;
                    if (cellValue == 1)
                    {
                        e.Graphics.DrawImage(wallImage, new Point(x, y));
                    }
                    if (cellValue == 2)
                    {
                        e.Graphics.DrawImage(rockImage, new Point(x, y));
                    }
                }
            }

            DrawBullets(e);

            DrawEnemyTanks(e);

            DrawEnemyBullets(e);
        }
    }

}
