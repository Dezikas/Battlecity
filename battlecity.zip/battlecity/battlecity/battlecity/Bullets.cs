﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace battlecity
{
    public class Bullet
    {
        public float X { get; set; }
        public float Y { get; set; }
        public float Speed { get; set; }
        public float Angle { get; set; }

        public Bullet(float x, float y, float speed, float angle)
        {
            X = x;
            Y = y;
            Speed = 5;
            Angle = angle;
        }

        public static float Radius { get; } = 2.5f;
    }

    public partial class Form1 : Form
    {
        private List<Bullet> bullets = new List<Bullet>();
        private bool isShooting = false;
        private System.Windows.Forms.Timer shootingCooldownTimer = new System.Windows.Forms.Timer();
        private bool canShoot = true;
        private int shootingCooldown = 500;
        private void UpdateBullets()
        {
            for (int i = bullets.Count - 1; i >= 0; i--)
            {
                Bullet bullet = bullets[i];
                float deltaX = (float)(Math.Cos(bullet.Angle * Math.PI / 180) * bullet.Speed);
                float deltaY = (float)(Math.Sin(bullet.Angle * Math.PI / 180) * bullet.Speed);
                bullet.X += deltaX;
                bullet.Y += deltaY;

                int bulletGridX = (int)(bullet.X / TileSize);
                int bulletGridY = (int)(bullet.Y / TileSize);

                // collisions with rocks
                if (bulletGridX >= 0 && bulletGridX < GridSize && bulletGridY >= 0 && bulletGridY < GridSize)
                {
                    int cellValue = map[bulletGridX, bulletGridY];
                    if (cellValue == 2)
                    {
                        map[bulletGridX, bulletGridY] = 0;
                        bullets.RemoveAt(i);
                        continue;
                    }
                }

                // collisions with walls
                if (bulletGridX >= 0 && bulletGridX < GridSize && bulletGridY >= 0 && bulletGridY < GridSize)
                {
                    int cellValue = map[bulletGridX, bulletGridY];
                    if (cellValue == 1)
                    {
                        bullets.RemoveAt(i);
                        continue;
                    }
                }

                // out of bounds
                if (bullet.X < 0 || bullet.X > ClientSize.Width || bullet.Y < 0 || bullet.Y > ClientSize.Height)
                {
                    bullets.RemoveAt(i);
                }
            }

            CheckBulletTankCollisions();
        }

        private void ShootingCooldownTimer_Tick(object sender, EventArgs e)
        {
            canShoot = true; // Reset the shooting cooldown, allowing the player to shoot again
            shootingCooldownTimer.Stop(); // Stop the timer until the player shoots again
        }

        private void CreateBullet()
        {
            if (!canShoot)
                return; // Player cannot shoot yet, exit the method

            float initialBulletAngle = tankRotationAngle - 90.0f;

            float bulletX = playerTank.Left + playerTank.Width / 2;
            float bulletY = playerTank.Top + playerTank.Height / 2;
            Bullet bullet = new Bullet(bulletX, bulletY, 8.0f, initialBulletAngle);
            bullets.Add(bullet);

            canShoot = false; // Set the shooting cooldown
            shootingCooldownTimer.Start(); // Start the cooldown timer
        }


        private void DrawBullets(PaintEventArgs e)
        {
            foreach (var bullet in bullets)
            {
                int bulletSize = 5;
                float bulletX = bullet.X - bulletSize / 2;
                float bulletY = bullet.Y - bulletSize / 2;
                e.Graphics.FillEllipse(Brushes.Black, bulletX, bulletY, bulletSize, bulletSize);
            }
        }
    private void CheckBulletTankCollisions()
        {
            for (int i = bullets.Count - 1; i >= 0; i--)
            {
                Bullet bullet = bullets[i];

                for (int j = enemyTanks.Count - 1; j >= 0; j--)
                {
                    EnemyTank enemyTank = enemyTanks[j];

                    float dx = bullet.X - enemyTank.X;
                    float dy = bullet.Y - enemyTank.Y;
                    float distance = (float)Math.Sqrt(dx * dx + dy * dy);

                    if (distance < Bullet.Radius + EnemyTank.Radius)
                    {
                        bullets.RemoveAt(i);
                        enemyTanks.RemoveAt(j);
                        break;
                    }
                }
            }
        }
    }
}
