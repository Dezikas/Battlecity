﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace battlecity
{
    public class EnemyBullet
    {
        public float X { get; set; }
        public float Y { get; set; }
        public float Speed { get; set; }
        public float Angle { get; set; }

        public EnemyBullet(float x, float y, float speed, float angle)
        {
            X = x;
            Y = y;
            Speed = speed;
            Angle = angle;
        }

        public static float Radius { get; } = 2.5f;
    }

    public partial class Form1 : Form
    {
        private List<EnemyBullet> enemyBullets = new List<EnemyBullet>();
        private System.Windows.Forms.Timer enemyTankBulletTimer = new System.Windows.Forms.Timer();


        private void UpdateEnemyBullets()
        {
            for (int i = enemyBullets.Count - 1; i >= 0; i--)
            {
                EnemyBullet enemyBullet = enemyBullets[i];
                float deltaX = (float)(Math.Cos(enemyBullet.Angle * Math.PI / 180) * enemyBullet.Speed);
                float deltaY = (float)(Math.Sin(enemyBullet.Angle * Math.PI / 180) * enemyBullet.Speed);
                enemyBullet.X += deltaX;
                enemyBullet.Y += deltaY;

                int enemyBulletX = (int)(enemyBullet.X / TileSize);
                int enemyBulletY = (int)(enemyBullet.Y / TileSize);

                // collisions with rocks
                if (enemyBulletX >= 0 && enemyBulletX < GridSize && enemyBulletY >= 0 && enemyBulletY < GridSize)
                {
                    int cellValue = map[enemyBulletX, enemyBulletY];
                    if (cellValue == 2)
                    {
                        map[enemyBulletX, enemyBulletY] = 0;
                        enemyBullets.RemoveAt(i);
                        continue;
                    }
                }

                // collisions with walls
                if (enemyBulletX >= 0 && enemyBulletX < GridSize && enemyBulletY >= 0 && enemyBulletY < GridSize)
                {
                    int cellValue = map[enemyBulletX, enemyBulletY];
                    if (cellValue == 1)
                    {
                        enemyBullets.RemoveAt(i);
                        continue;
                    }
                }

                if (enemyBullet.X < 0 || enemyBullet.X > ClientSize.Width || enemyBullet.Y < 0 || enemyBullet.Y > ClientSize.Height)
                {
                    enemyBullets.RemoveAt(i);
                }
            }

            CheckBulletPlayerTankCollisions();
        }

        private void DrawEnemyBullets(PaintEventArgs e)
        {
            foreach (var enemyBullet in enemyBullets)
            {
                int bulletSize = 5;
                float bulletX = enemyBullet.X - bulletSize / 2;
                float bulletY = enemyBullet.Y - bulletSize / 2;
                e.Graphics.FillEllipse(Brushes.Red, bulletX, bulletY, bulletSize, bulletSize);
            }
        }

        private void CheckBulletPlayerTankCollisions()
        {
            for (int i = enemyBullets.Count - 1; i >= 0; i--)
            {
                EnemyBullet enemyBullet = enemyBullets[i];

                float dx = enemyBullet.X - playerTank.Left;
                float dy = enemyBullet.Y - playerTank.Top;
                float distance = (float)Math.Sqrt(dx * dx + dy * dy);

                if (distance < EnemyBullet.Radius + playerTank.Width / 2)
                {
                    enemyBullets.RemoveAt(i);
                    IsGameOver = true;
                    break;
                }
            }
        }

        private void EnemyTankBulletTimer_Tick(object sender, EventArgs e)
        {
            foreach (var enemyTank in enemyTanks)
            {
                float initialBulletAngle = GetRotationAngle(enemyTank.Direction) - 90.0f;

                float bulletX = enemyTank.X + EnemyTank.Radius;
                float bulletY = enemyTank.Y + EnemyTank.Radius;

                EnemyBullet enemyBullet = new EnemyBullet(bulletX, bulletY, 8.0f, initialBulletAngle);
                enemyBullets.Add(enemyBullet);
            }
        }


    }
}
