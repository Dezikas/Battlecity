﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static battlecity.Form1;

namespace battlecity
{
    public class EnemyTank
    {
        public float X { get; set; }
        public float Y { get; set; }
        public float Speed { get; set; }
        public TankDirection Direction { get; set; }

        public EnemyTank(float x, float y, float speed, TankDirection direction)
        {
            X = x;
            Y = y;
            Speed = speed;
            Direction = direction;
        }

        public static float Radius { get; } = 16.0f;
    }

    public partial class Form1 : Form
    {
     

        private List<Point> enemyTankPositions = new List<Point>
        {
            new Point(500, 100),
            new Point(700, 200),
            new Point(300, 300),
            new Point(400, 700),
            new Point(600, 600),
        };

        private void InitializeEnemyTanks()
        {
            for (int i = 0; i < 5; i++)
            {
                Point position = enemyTankPositions[i];
                float initialX = position.X;
                float initialY = position.Y;

                EnemyTank enemyTank = new EnemyTank(initialX, initialY, 1.0f, 0.0f);
                enemyTanks.Add(enemyTank);
            }
        }
        public enum TankDirection
        {
            Up,
            Down,
            Left,
            Right
        }


        private void UpdateEnemyTanks()
        {
            foreach (var enemyTank in enemyTanks)
            {
                float newX = enemyTank.X;
                float newY = enemyTank.Y;

                switch (enemyTank.Direction)
                {
                    case TankDirection.Up:
                        newY -= enemyTank.Speed;
                        break;
                    case TankDirection.Down:
                        newY += enemyTank.Speed;
                        break;
                    case TankDirection.Left:
                        newX -= enemyTank.Speed;
                        break;
                    case TankDirection.Right:
                        newX += enemyTank.Speed;
                        break;
                }

                if (IsCollidingEnemy(newX, newY, enemyTank))
                {
                    enemyTank.X = newX;
                    enemyTank.Y = newY;
                }
                else
                {
                    enemyTank.Direction = GetRandomDirection();
                }

            }


        }

        private TankDirection GetRandomDirection()
        {
            int randomDirection = random.Next(4);

            switch (randomDirection)
            {
                case 0:
                    return TankDirection.Left;
                case 1:
                    return TankDirection.Right;
                case 2:
                    return TankDirection.Down;
                case 3:
                    return TankDirection.Up;
                default:
                    return TankDirection.Down;
            }
        }



        private bool IsCollidingEnemy(float newX, float newY, EnemyTank tankToCheck)
        {
            int newGridX = (int)(newX / TileSize);
            int newGridY = (int)(newY / TileSize);

            int tankGridLeft = (int)(newX / TileSize);
            int tankGridRight = (int)((newX + EnemyTank.Radius * 2) / TileSize);
            int tankGridTop = (int)(newY / TileSize);
            int tankGridBottom = (int)((newY + EnemyTank.Radius * 2) / TileSize);

            if (newGridX < 0 || newGridX >= GridSize || newGridY < 0 || newGridY >= GridSize)
            {
                return false;
            }

            if (map[newGridX, newGridY] == 1 ||
                map[tankGridRight, tankGridTop] == 1 ||
                map[tankGridLeft, tankGridBottom] == 1 ||
                map[tankGridRight, tankGridBottom] == 1 ||
                map[newGridX, newGridY] == 2 ||
                map[tankGridRight, tankGridTop] == 2 ||
                map[tankGridLeft, tankGridBottom] == 2 ||
                map[tankGridRight, tankGridBottom] == 2
                )
            {
                return false;
            }

            foreach (var enemyTank in enemyTanks)
            {
                if (enemyTank != tankToCheck)
                {
                    // coordinates of the other tank
                    int otherTankGridLeft = (int)(enemyTank.X / TileSize);
                    int otherTankGridRight = (int)((enemyTank.X + EnemyTank.Radius * 2) / TileSize);
                    int otherTankGridTop = (int)(enemyTank.Y / TileSize);
                    int otherTankGridBottom = (int)((enemyTank.Y + EnemyTank.Radius * 2) / TileSize);

                    // overlap with the other tank
                    if (tankGridRight >= otherTankGridLeft && tankGridLeft <= otherTankGridRight &&
                        tankGridBottom >= otherTankGridTop && tankGridTop <= otherTankGridBottom)
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        private void DrawEnemyTanks(PaintEventArgs e)
        {
            foreach (var enemyTank in enemyTanks)
            {
                Image rotatedEnemyTank = RotateImage((Bitmap)originalTankImage, GetRotationAngle(enemyTank.Direction));
                e.Graphics.DrawImage(rotatedEnemyTank, enemyTank.X, enemyTank.Y);
            }
        }

        private float GetRotationAngle(TankDirection direction)
        {
            switch (direction)
            {
                case TankDirection.Up:
                    return 0.0f;
                case TankDirection.Down:
                    return 180.0f;
                case TankDirection.Left:
                    return -90.0f;
                case TankDirection.Right:
                    return 90.0f;
                default:
                    return 0.0f;
            }
        }
    }
}
